## Steps to Install and Configure
- Create virtual env and activate
- pip install -r requirements.txt
- locust -f script.py
- Check http://localhost:8089
- Enter Host name :  https://staging.chemer.in
